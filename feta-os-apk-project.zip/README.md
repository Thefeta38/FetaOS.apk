# FETA OS — Launcher APK

Το FETA OS εγκαθίσταται ως εφαρμογή και μπορεί να οριστεί ως η αρχική οθόνη (launcher) του κινητού.
Έχει πλήρη οθόνη, δικαιώματα κάμερας/μικροφώνου και εφαρμογή «Εφαρμογές κινητού» που ανοίγει τις πραγματικές εφαρμογές.

## Μέθοδος Α: GitHub (χωρίς εγκατάσταση προγραμμάτων)
1. Φτιάξε δωρεάν λογαριασμό στο github.com και ένα repository. Αν έχεις ήδη, διέγραψε τα παλιά αρχεία.
2. Αποσυμπίεσε το zip και ανέβασε ΟΛΑ τα περιεχόμενα (Add file → Upload files), μαζί με τον φάκελο `.github`.
   Αν δεν ανεβεί, φτιάξε το `.github/workflows/build-apk.yml` χειροκίνητα (Add file → Create new file) και επικόλλησε το περιεχόμενο.
3. Tab **Actions** → **Build APK** → **Run workflow** (5–8 λεπτά).
4. Στο ολοκληρωμένο run, κατέβασε το Artifact `feta-os-apk`, αποσυμπίεσέ το και εγκατέστησε το `app-debug.apk`.

## Ορισμός ως αρχική οθόνη
Πάτα το κουμπί Home → διάλεξε **FETA OS** → **Πάντα**.
Για επαναφορά: Ρυθμίσεις → Εφαρμογές → Προεπιλεγμένες εφαρμογές → Αρχική οθόνη.

## Μέθοδος Β: Android Studio
```
npm install
npx cap add android
node scripts/patch-android.js
npx cap sync android
npx cap open android
```
Build → Build APK(s).
